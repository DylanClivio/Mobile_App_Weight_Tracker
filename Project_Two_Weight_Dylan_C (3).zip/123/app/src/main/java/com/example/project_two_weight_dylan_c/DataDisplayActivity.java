package com.example.project_two_weight_dylan_c;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class DataDisplayActivity extends AppCompatActivity {

    private EditText dataEditText;
    private Button addButton;
    private TableLayout tableLayout;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        // Initialize views
        dataEditText = findViewById(R.id.dataEditText);
        addButton = findViewById(R.id.addButton);
        tableLayout = findViewById(R.id.tableLayout);

        // Initialize database helper
        dbHelper = new DatabaseHelper(this);

        // Load data from the database and display it in the table
        loadData();

        // Set onClick listener for the add button
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addData();
            }
        });
    }

    // Method to add data to the database
    private void addData() {
        String weight = dataEditText.getText().toString().trim();

        if (weight.isEmpty()) {
            Toast.makeText(this, "Please enter a weight", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_WEIGHT_VALUE, weight);
        values.put(DatabaseHelper.COLUMN_WEIGHT_DATE, System.currentTimeMillis()); // Store the current time as the date

        long newRowId = db.insert(DatabaseHelper.TABLE_WEIGHT, null, values);

        if (newRowId != -1) {
            Toast.makeText(this, "Data added successfully", Toast.LENGTH_SHORT).show();
            dataEditText.setText(""); // Clear the input field
            loadData(); // Refresh the table
        } else {
            Toast.makeText(this, "Error adding data", Toast.LENGTH_SHORT).show();
        }
    }

    // Method to load data from the database and display it in the table
    private void loadData() {
        tableLayout.removeAllViews(); // Clear the table

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(
                DatabaseHelper.TABLE_WEIGHT,
                null,
                null,
                null,
                null, null, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ID));
                String weight = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_WEIGHT_VALUE));
                long dateMillis = cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_WEIGHT_DATE));

                // Convert date from milliseconds to a readable format
                String date = android.text.format.DateFormat.format("yyyy-MM-dd HH:mm:ss", new java.util.Date(dateMillis)).toString();

                // Add a new row to the table
                addTableRow(id, weight, date);
            }
            cursor.close();
        }
    }

    // Method to add a row to the table
    private void addTableRow(int id, String weight, String date) {
        TableRow row = new TableRow(this);

        TextView weightTextView = new TextView(this);
        weightTextView.setText(weight);
        row.addView(weightTextView);

        TextView dateTextView = new TextView(this);
        dateTextView.setText(date);
        row.addView(dateTextView);

        // Add Update and Delete buttons
        Button updateButton = new Button(this);
        updateButton.setText("Update");
        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateData(id, weight);
            }
        });
        row.addView(updateButton);

        Button deleteButton = new Button(this);
        deleteButton.setText("Delete");
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteData(id);
            }
        });
        row.addView(deleteButton);

        tableLayout.addView(row);
    }

    // Method to update a specific data entry
    private void updateData(int id, String currentWeight) {
        EditText updateEditText = new EditText(this);
        updateEditText.setText(currentWeight);

        // Prompt user for the new value (in a real app, you might use a dialog instead)
        Toast.makeText(this, "Enter new value for weight and click OK", Toast.LENGTH_LONG).show();

        updateEditText.setOnEditorActionListener((v, actionId, event) -> {
            String newWeight = updateEditText.getText().toString().trim();

            if (!newWeight.isEmpty()) {
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                ContentValues values = new ContentValues();
                values.put(DatabaseHelper.COLUMN_WEIGHT_VALUE, newWeight);

                int rowsAffected = db.update(
                        DatabaseHelper.TABLE_WEIGHT,
                        values,
                        DatabaseHelper.COLUMN_ID + "=?",
                        new String[]{String.valueOf(id)});

                if (rowsAffected > 0) {
                    Toast.makeText(DataDisplayActivity.this, "Data updated successfully", Toast.LENGTH_SHORT).show();
                    loadData(); // Refresh the table
                } else {
                    Toast.makeText(DataDisplayActivity.this, "Error updating data", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(DataDisplayActivity.this, "Please enter a weight", Toast.LENGTH_SHORT).show();
            }

            return true;
        });

        tableLayout.addView(updateEditText);
    }

    // Method to delete a specific data entry
    private void deleteData(int id) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        int rowsDeleted = db.delete(
                DatabaseHelper.TABLE_WEIGHT,
                DatabaseHelper.COLUMN_ID + "=?",
                new String[]{String.valueOf(id)});

        if (rowsDeleted > 0) {
            Toast.makeText(this, "Data deleted successfully", Toast.LENGTH_SHORT).show();
            loadData(); // Refresh the table
        } else {
            Toast.makeText(this, "Error deleting data", Toast.LENGTH_SHORT).show();
        }
    }
}